Islamic Prayer Times for Arduino
===========
Tested on Arduino :
- Mega 2560
- Uno

Adabted for arduino from this site: http://praytimes.org/manual/
